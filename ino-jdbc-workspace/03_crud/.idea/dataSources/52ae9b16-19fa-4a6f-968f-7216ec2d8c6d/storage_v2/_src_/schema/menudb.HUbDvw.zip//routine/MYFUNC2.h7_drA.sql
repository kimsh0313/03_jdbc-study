create
    definer = ino@`%` function MYFUNC2(param_menu varchar(50), param_category_code int) returns varchar(100)
BEGIN
    DECLARE emoji CHAR(1);
    CASE param_category_code
        WHEN 4 THEN SET emoji = '🍕';
        WHEN 5 THEN SET emoji = '🍔';
        WHEN 6 THEN SET emoji = '🍟';
        ELSE SET emoji = '🌭';
    END CASE;
    RETURN CONCAT(emoji, param_menu, emoji);
END;

