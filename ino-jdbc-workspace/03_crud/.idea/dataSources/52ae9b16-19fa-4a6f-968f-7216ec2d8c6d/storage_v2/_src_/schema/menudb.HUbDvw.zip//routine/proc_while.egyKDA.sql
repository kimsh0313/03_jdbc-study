create
    definer = ino@`%` procedure proc_while(IN n int, OUT result int)
BEGIN
    DECLARE i INT DEFAULT 1;
    SET result = 0;
    WHILE i <= n DO
        IF i % 2 = 0 
            THEN SET result = result + i;
        END IF;
        SET i = i + 1;
    END WHILE;
END;

