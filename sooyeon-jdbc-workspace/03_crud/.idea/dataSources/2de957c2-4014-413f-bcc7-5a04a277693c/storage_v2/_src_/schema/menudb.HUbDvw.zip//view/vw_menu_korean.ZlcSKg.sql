create definer = sotogito@`%` view vw_menu_korean as
select `m`.`menu_code`        AS `menu_code`,
       `m`.`menu_name`        AS `menu_name`,
       `m`.`menu_price`       AS `menu_price`,
       `c`.`category_name`    AS `category_name`,
       `m`.`orderable_status` AS `orderable_status`
from (`menudb`.`tbl_menu` `m` join `menudb`.`tbl_category` `c` on ((`c`.`category_code` = `m`.`category_code`)))
where (`c`.`category_name` = '한식');

-- comment on column vw_menu_korean.menu_code not supported: 메뉴코드

-- comment on column vw_menu_korean.menu_name not supported: 메뉴명

-- comment on column vw_menu_korean.menu_price not supported: 메뉴가격

-- comment on column vw_menu_korean.category_name not supported: 카테고리명

-- comment on column vw_menu_korean.orderable_status not supported: 주문가능상태

