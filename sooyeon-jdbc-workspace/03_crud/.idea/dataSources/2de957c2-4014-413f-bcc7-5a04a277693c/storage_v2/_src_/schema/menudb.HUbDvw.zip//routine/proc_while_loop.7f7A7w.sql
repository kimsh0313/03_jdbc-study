create
    definer = sotogito@`%` procedure proc_while_loop(IN n int, OUT sum int)
BEGIN
    DECLARE i INT DEFAULT 1;
    SET sum = 0;
    WHILE i <= n DO
    
        IF i%2 = 0
            THEN SET sum = sum + i;
        END IF;
        SET i = i+1;
    END WHILE;
END;

