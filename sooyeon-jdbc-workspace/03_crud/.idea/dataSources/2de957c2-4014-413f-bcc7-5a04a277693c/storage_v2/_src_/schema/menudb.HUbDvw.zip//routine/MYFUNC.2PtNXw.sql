create
    definer = sotogito@`%` function MYFUNC(param_menu varchar(50)) returns varchar(100)
BEGIN
    DECLARE result VARCHAR(100); # 결과를 담을 변수 선언
    SET result = CONCAT('*',param_menu,'☜');
    RETURN result;
END;

