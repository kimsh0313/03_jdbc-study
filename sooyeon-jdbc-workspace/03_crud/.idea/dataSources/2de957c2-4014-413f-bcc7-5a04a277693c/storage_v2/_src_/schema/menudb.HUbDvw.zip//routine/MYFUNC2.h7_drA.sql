create
    definer = sotogito@`%` function MYFUNC2(para_menu varchar(50), para_category_code int) returns varchar(100)
BEGIN
    DECLARE result VARCHAR(100);
    DECLARE EMOJI CHAR(1);
    CASE param_category_code
        WHEN 4 THEN SET emoji = '🥗🥗🥗🥗';
        WHEN 5 THEN SET emoji = '🍜🍜🍜';
        WHEN 6 THEN SET emoji = '🍣🍣🍣🍣';
        ELSE SET emoji = '😁😁😁😁😁😁😁😁😁😁';
    END CASE;
    RETURN CONCAT(emoji,para_menu,emoji);
END;

