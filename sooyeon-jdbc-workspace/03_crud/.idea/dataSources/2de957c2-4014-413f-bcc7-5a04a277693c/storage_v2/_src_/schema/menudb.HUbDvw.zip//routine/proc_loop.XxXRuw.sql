create
    definer = sotogito@`%` procedure proc_loop(IN n int, OUT sum int)
BEGIN
    DECLARE i INT DEFAULT 1;
    SET sum = 0;
    sum_lable: LOOP
        SET sum = sum + i;
        SET i = i+1;
        IF i > n THEN LEAVE sum_lable;
        END IF;
    END LOOP;
END;

