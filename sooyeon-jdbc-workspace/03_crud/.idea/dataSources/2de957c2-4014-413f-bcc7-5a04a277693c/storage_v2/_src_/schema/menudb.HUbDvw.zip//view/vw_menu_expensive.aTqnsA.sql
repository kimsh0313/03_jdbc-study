create definer = sotogito@`%` view vw_menu_expensive as
select `menudb`.`tbl_menu`.`menu_code`        AS `menu_code`,
       `menudb`.`tbl_menu`.`menu_name`        AS `menu_name`,
       `menudb`.`tbl_menu`.`menu_price`       AS `menu_price`,
       `menudb`.`tbl_menu`.`category_code`    AS `category_code`,
       `menudb`.`tbl_menu`.`orderable_status` AS `orderable_status`
from `menudb`.`tbl_menu`
where (`menudb`.`tbl_menu`.`menu_price` >= 20000);

-- comment on column vw_menu_expensive.menu_code not supported: 메뉴코드

-- comment on column vw_menu_expensive.menu_name not supported: 메뉴명

-- comment on column vw_menu_expensive.menu_price not supported: 메뉴가격

-- comment on column vw_menu_expensive.category_code not supported: 카테고리코드

-- comment on column vw_menu_expensive.orderable_status not supported: 주문가능상태

