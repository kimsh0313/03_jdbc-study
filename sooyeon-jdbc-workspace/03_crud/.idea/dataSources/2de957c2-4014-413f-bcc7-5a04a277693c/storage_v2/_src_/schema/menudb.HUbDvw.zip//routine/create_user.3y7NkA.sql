create
    definer = sotogito@`%` procedure create_user(IN username varchar(50), IN password varchar(16), OUT mem_id int)
BEGIN
    INSERT INTO
        tbl_member(username,password)
    VALUES
        (username,password);
        
    SET mem_id = LAST_INSERT_ID();
END;

